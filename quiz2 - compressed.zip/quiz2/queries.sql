CREATE TABLE IF NOT EXISTS Patients(
	patient_id SERIAL PRIMARY KEY,
	name VARCHAR(100) NOT NULL,
	gender CHAR NOT NULL,
	dob DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS Doctors(
	doctor_id SERIAL PRIMARY KEY,
	name VARCHAR(100) NOT NULL,
	specialization VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS Visits(
	visit_id SERIAL PRIMARY KEY,
	patient_id INT,
	doctor_id INT,
	visit_date DATE NOT NULL,
	FOREIGN KEY(patient_id) REFERENCES Patients(patient_id),
	FOREIGN KEY(doctor_id) REFERENCES Doctors(doctor_id)
);

CREATE TABLE IF NOT EXISTS Treatments(
	treatment_id SERIAL PRIMARY KEY,
	visit_id INT,
	cost INT NOT NULL CHECK(cost >= 0),
	FOREIGN KEY(visit_id) REFERENCES Visits(visit_id)
);



-- COPY patients FROM 'D:\Project3_Hospital_SQL_BIG.csv' WITH (FORMAT csv, HEADER true, DELIMITER ',');
-- COPY doctors FROM 'D:\Books\SQL FILES\doctors.txt' WITH (FORMAT csv, HEADER true, DELIMITER ',');
-- COPY visits FROM 'D:\Books\SQL FILES\visits.csv' WITH (FORMAT csv, HEADER true, DELIMITER ',');
-- COPY treatments FROM 'D:\Books\SQL FILES\treatments.csv' WITH (FORMAT csv, HEADER true, DELIMITER ',');

-- Section A

-- 1. Display all patients with their gender and date of birth.
SELECT gender, dob
FROM patients;

-- 2. List all doctors and their specializations.
SELECT *
FROM doctors;





-- 3. Show all visits that occurred in the last 30 days.
SELECT *
FROM visits vs
WHERE vs.visit_date >= NOW() - INTERVAL '30 days';





-- 4. Display all visits handled by a specific doctor (e.g., Doctor_5).
SELECT *
FROM visits
WHERE doctor_id = 5;



-- 5. Count the total number of patients in the hospital.
SELECT COUNT(*)
FROM patients;






-- Section B: Joins & Medical Reporting

-- 6. Display patient name, doctor name, and visit date for every visit.
SELECT pt.name, dc.name, vs.visit_date
FROM visits vs
INNER JOIN patients pt ON pt.patient_id = vs.patient_id
INNER JOIN doctors dc ON dc.doctor_id = vs.doctor_id;





-- 7. Show a list of patients and the doctors who treated them.
SELECT pt.name, dc.name
FROM treatments tm
INNER JOIN visits vs ON vs.visit_id = tm.visit_id
INNER JOIN patients pt ON pt.patient_id = vs.patient_id
INNER JOIN doctors dc ON dc.doctor_id = vs.doctor_id;


-- 8. Display visit details, including treatment cost.
SELECT tm.treatment_id, tm.cost, vs.visit_date
FROM treatments tm
INNER JOIN visits vs ON vs.visit_id = tm.visit_id;



-- 9. List all visits where the treatment cost is greater than 300. 
SELECT tm.treatment_id, tm.cost, vs.visit_date
FROM visits vs
INNER JOIN treatments tm ON tm.visit_id = vs.visit_id
WHERE tm.cost > 300;

-- 10. Show all patients who were treated by doctors in cardiology.
SELECT pt.name, dc.name, tm.cost, dc.specialization
FROM treatments tm
INNER JOIN visits vs ON vs.visit_id = tm.visit_id
INNER JOIN doctors dc ON dc.doctor_id = vs.doctor_id
INNER JOIN patients pt ON pt.patient_id = vs.patient_id
WHERE dc.specialization = 'Cardiology';



-- Section C: Doctor Workload Analysis

-- 11. Count the number of visits handled by each doctor.
SELECT dc.name, COUNT(dc.doctor_id) AS "Number of Visits"
FROM visits vs
INNER JOIN doctors dc ON dc.doctor_id = vs.doctor_id
GROUP BY dc.doctor_id;


-- 12. List doctors who handled more than 50 visits.

SELECT *
FROM (
	SELECT dc.name, dc.specialization, COUNT(dc.doctor_id) AS visit_count
	FROM visits vs
	INNER JOIN doctors dc ON dc.doctor_id = vs.doctor_id
	GROUP BY dc.doctor_id
)
WHERE visit_count > 50;


-- 13. Find the doctor with the highest number of visits.
SELECT *
FROM (
	SELECT dc.name, dc.specialization, COUNT(dc.doctor_id) AS visit_count
	FROM visits vs
	INNER JOIN doctors dc ON dc.doctor_id = vs.doctor_id
	GROUP BY dc.doctor_id
)
ORDER BY visit_count DESC
LIMIT 1;



-- 14. Calculate the average number of visits per doctor.

SELECT AVG(visit_count)
FROM (
	SELECT dc.name, COUNT(dc.doctor_id) AS visit_count
	FROM visits vs
	INNER JOIN doctors dc ON dc.doctor_id = vs.doctor_id
	GROUP BY dc.doctor_id
);


-- 15. Rank doctors by number of patients treated (MySQL 8+).
SELECT *
FROM (
	SELECT dc.name, COUNT(*)
	FROM treatments tm
	INNER JOIN visits vs ON vs.visit_id = tm.visit_id
	INNER JOIN doctors dc ON dc.doctor_id = vs.doctor_id
	GROUP BY dc.doctor_id
)
ORDER BY count DESC;

